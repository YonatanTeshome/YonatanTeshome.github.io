import Projects from "./Projects";
export default function App() { return <Projects />; }
